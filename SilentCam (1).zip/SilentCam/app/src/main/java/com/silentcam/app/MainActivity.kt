package com.silentcam.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.Surface
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 무음 카메라
 *
 * 핵심 원리: ImageCapture(정지 사진 캡처 파이프라인)를 쓰지 않는다.
 * 일부 제조사(특히 국내 판매 단말)는 still capture 요청 시 HAL/시스템 레벨에서
 * 셔터음을 강제하므로, 대신 ImageAnalysis 스트림(연속 프레임)에서 요청 시점의
 * 한 프레임을 가로채 JPEG로 저장한다. 스트림 프레임에는 셔터음이 발생하지 않는다.
 *
 * 트레이드오프: 해상도가 기기의 분석 스트림 최대치(보통 1080p~12MP)로 제한되고,
 * 제조사 ISP의 still 전용 후처리(멀티프레임 NR, HDR)가 적용되지 않는다.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var flashOverlay: View
    private lateinit var captureButton: ImageButton
    private lateinit var torchButton: Button

    private lateinit var analysisExecutor: ExecutorService
    private val captureRequested = AtomicBoolean(false)

    private var camera: Camera? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var torchOn = false

    private lateinit var orientationListener: OrientationEventListener

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            arrayOf(Manifest.permission.CAMERA)
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) startCamera()
            else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        flashOverlay = findViewById(R.id.flashOverlay)
        captureButton = findViewById(R.id.captureButton)
        torchButton = findViewById(R.id.torchButton)
        analysisExecutor = Executors.newSingleThreadExecutor()

        // targetSdk 35는 edge-to-edge 강제 → 하단 컨트롤이 내비게이션 바에 가리지 않도록 인셋 적용
        val controls = findViewById<View>(R.id.controls)
        val baseBottom = controls.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(controls) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(bottom = baseBottom + bars.bottom)
            insets
        }

        captureButton.setOnClickListener { requestCapture() }
        findViewById<Button>(R.id.switchButton).setOnClickListener { switchCamera() }
        torchButton.setOnClickListener { toggleTorch() }
        setupTapToFocus()

        // 화면은 세로 고정이지만, 기기를 돌려 찍으면 사진 방향이 맞도록 targetRotation 갱신
        orientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val rotation = when (orientation) {
                    in 45 until 135 -> Surface.ROTATION_270
                    in 135 until 225 -> Surface.ROTATION_180
                    in 225 until 315 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                imageAnalysis?.targetRotation = rotation
            }
        }

        if (hasPermissions()) startCamera() else permissionLauncher.launch(requiredPermissions)
    }

    override fun onStart() {
        super.onStart()
        orientationListener.enable()
    }

    override fun onStop() {
        super.onStop()
        orientationListener.disable()
    }

    override fun onDestroy() {
        super.onDestroy()
        analysisExecutor.shutdown()
    }

    /** 볼륨 키로도 촬영 (키 이벤트를 소비해서 볼륨 UI/효과음이 뜨지 않게 함) */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event?.repeatCount == 0) requestCapture()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) return true
        return super.onKeyUp(keyCode, event)
    }

    private fun hasPermissions() = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            // 4:3 최대 해상도를 요청. 기기가 Preview+Analysis 동시 스트림에서 허용하는
            // 가장 가까운 하위 해상도로 자동 폴백된다.
            val resolutionSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(4000, 3000),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()

            val preview = Preview.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                        .build()
                )
                .build()
                .also { it.surfaceProvider = previewView.surfaceProvider }

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(resolutionSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            // 평소엔 프레임을 즉시 버리고, 촬영 요청 플래그가 켜진 순간의 프레임만 저장
            analysis.setAnalyzer(analysisExecutor) { image ->
                if (captureRequested.compareAndSet(true, false)) {
                    saveFrame(image)
                }
                image.close()
            }

            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, analysis)
                imageAnalysis = analysis
                torchOn = false
                updateTorchUi()
            } catch (e: Exception) {
                Toast.makeText(this, "카메라 시작 실패: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun requestCapture() {
        if (camera == null) return
        captureButton.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        playFlashAnimation()
        captureRequested.set(true)
    }

    /** 분석 스레드에서 실행: RGBA 프레임 → 회전/미러 보정 → JPEG → MediaStore */
    private fun saveFrame(image: ImageProxy) {
        val rotation = image.imageInfo.rotationDegrees
        val raw = image.toBitmap()

        val matrix = Matrix().apply {
            postRotate(rotation.toFloat())
            // 전면 카메라는 미리보기와 동일하게 좌우 반전
            if (lensFacing == CameraSelector.LENS_FACING_FRONT) postScale(-1f, 1f)
        }
        val bitmap = if (rotation == 0 && lensFacing == CameraSelector.LENS_FACING_BACK) raw
        else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)

        val name = "SILENT_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SilentCam")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        val ok = uri != null && runCatching {
            resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            } ?: false
        }.getOrDefault(false)

        if (uri != null) {
            if (ok && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } else if (!ok) {
                resolver.delete(uri, null, null) // 실패한 빈 항목 정리
            }
        }

        val size = "${bitmap.width}x${bitmap.height}"
        if (bitmap !== raw) bitmap.recycle()
        raw.recycle()

        runOnUiThread {
            val msg = if (ok) getString(R.string.saved, size)
            else getString(R.string.save_failed)
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    /** 스트림 캡처라 촬영용 플래시는 불가 → 지속 조명(torch)으로 대체 */
    private fun toggleTorch() {
        val cam = camera ?: return
        if (!cam.cameraInfo.hasFlashUnit()) {
            Toast.makeText(this, "이 카메라에는 조명이 없습니다", Toast.LENGTH_SHORT).show()
            return
        }
        torchOn = !torchOn
        cam.cameraControl.enableTorch(torchOn)
        updateTorchUi()
    }

    private fun updateTorchUi() {
        torchButton.alpha = if (torchOn) 1f else 0.6f
        torchButton.text = if (torchOn) "조명 ON" else getString(R.string.torch)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTapToFocus() {
        previewView.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val point = previewView.meteringPointFactory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(point).build()
                camera?.cameraControl?.startFocusAndMetering(action)
                v.performClick()
            }
            true
        }
    }

    private fun playFlashAnimation() {
        flashOverlay.animate().cancel()
        flashOverlay.alpha = 0.7f
        flashOverlay.animate().alpha(0f).setDuration(150).start()
    }
}
