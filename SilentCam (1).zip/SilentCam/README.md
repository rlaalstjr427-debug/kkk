# SilentCam (무음 카메라)

CameraX 기반 안드로이드 무음 카메라. 셔터음이 나는 정지 사진 캡처(ImageCapture) 대신
ImageAnalysis 프레임 스트림에서 촬영 시점의 한 프레임을 JPEG로 저장한다.

## 빌드
1. Android Studio(Ladybug 이상)에서 `SilentCam` 폴더를 Open
2. Gradle Sync — wrapper jar는 Studio가 자동 생성/다운로드
3. 기기 연결 후 Run ▶ (minSdk 26 / Android 8.0+)

## 기능
- 셔터 버튼 / 볼륨 키(위·아래) 촬영, 진동 + 화면 깜빡임으로 촬영 피드백
- 전·후면 전환, 조명(torch), 탭 초점
- 저장 위치: `Pictures/SilentCam/SILENT_yyyyMMdd_HHmmss_SSS.jpg`

## 한계 (구조적 트레이드오프)
- 해상도: 기기가 Preview+Analysis 동시 스트림에 허용하는 최대치로 제한 (보통 1080p~12MP, 기본 카메라 50MP급 불가)
- 화질: 제조사 still 후처리(멀티프레임 NR·HDR) 미적용 → 저조도에서 노이즈 증가
- 플래시: 촬영용 순간 플래시 불가, 지속 조명으로 대체
- EXIF 메타데이터(위치·노출 정보) 미기록
